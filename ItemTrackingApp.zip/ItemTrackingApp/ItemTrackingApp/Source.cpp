// Tiffany Usher
// 6/21/24
// Program prompts the user to input a grocery item to search for and prints the frequencies of the items within the list while it reads and writes to files.
#include <iostream>
#include <fstream>
#include <map>

using namespace std;

class ItemTracker { // ItemTracker class declared
private:
    map<string, int> itemFreq; // Mapping strings to integers

public:
    ItemTracker() {
        ifstream inputFile("FoodListInputFile.txt"); // Input file is opened for reading
        if (!inputFile.is_open()) {
            cerr << "Error opening input file." << endl;
        }
        else {
            string item;
            while (inputFile >> item) {
                itemFreq[item]++;
            }
            inputFile.close(); // Closing the file
        }
    }

    int getFrequency(string item) { // This function returns the frequency of a searched item
        return itemFreq[item];
    }

    void displayList() { // Function displays the list of all item frequencies
        for (const auto& pair : itemFreq) { // Using a range based for-loop and iterating over key value pairs
            cout << pair.first << " " << pair.second << endl;
        }
    }

    void displayHistogram() { // Displaying the histogram of all item frequencies
        for (const auto& pair : itemFreq) {
            cout << pair.first << " ";
            for (int i = 0; i < pair.second; ++i) {
                cout << "*";
            }
            cout << endl;
        }
    }

    void backupFile() {
        ofstream outputFile("frequency.dat"); // Opening data backup file. All items and their frequencies are written to it
        if (!outputFile.is_open()) {
            cerr << "Error opening output file." << endl;
        }
        else {
            for (const auto& pair : itemFreq) {
                outputFile << pair.first << " " << pair.second << endl;
            }
            outputFile.close(); // Closing the file
        }
    }
};

int main() {
    ItemTracker tracker; // Declaring "tracker" object for ItemTracker class

    while (true) {
        cout << "** CORNER GROCER TRACKER **" << endl; // Menu options are printed
        cout << endl;
        cout << "[1] Search for item frequency" << endl;
        cout << "[2] Print list of item frequencies" << endl;
        cout << "[3] Print histogram of item frequencies" << endl;
        cout << "[4] Exit" << endl;
        cout << "Enter choice: ";

        int choice;
        cin >> choice; // Prompting user to input a menu choice

        switch (choice) { // Switch-case statement for choosing the four options
        case 1: {
            string item;
            cout << "Search for an item: ";
            cin >> item;
            cout << item << ": " << tracker.getFrequency(item) << endl;
            break;
        }
        case 2: {
            tracker.displayList(); // Calling "displayList" and subsequent functions with the "tracker" object
            tracker.backupFile();
            break;
        }
        case 3: {
            tracker.displayHistogram();
            tracker.backupFile();
            break;
        }
        case 4: {
            cout << "File conversion successful." << endl;
            tracker.backupFile();
            return 0;
        }
        default: {
            cout << "Invalid. Please try again." << endl;
            break;
        }
        }
    }
    return 0;
}
